import './App.css';

import { connect } from 'react-redux';

function App({ play, isPlaying, player, message }) {
    const pingClasses = ['ping', player == 1 ? 'left' : 'right'];

    return (
        <div className='App'>
            <button onClick={play}>Let's play !</button>
            <p>Message : {message}</p>
            <div className='players'>
                <div className='player'>Player 1</div>
                <div className='player'>Player 2</div>
            </div>
            <div className={pingClasses.join(' ')}>
                <img
                    src='/ping.png'
                    width='200'
                    className={!isPlaying ? 'hidden' : ''}
                />
            </div>
        </div>
    );
}

const mstp = state => {
    return {
        isPlaying: state.isPlaying,
        player: state.player,
        message: state.message,
    };
};

const mdtp = dispatch => {
    return {
        play: () => dispatch({ type: 'PLAY' }),
    };
};

export default connect(mstp, mdtp)(App);
