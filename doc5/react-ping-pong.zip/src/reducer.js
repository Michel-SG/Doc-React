const initialState = {
    player: 1,
    message: 'Launch a game !',
    isPlaying: false,
};

export default function reducer(state = initialState, action) {
    switch (action.type) {
        case 'GAMESTART':
            return { player: 1, message: 'New game !' };
        case 'PING':
            return {
                isPlaying: true,
                player: state.player == 1 ? 2 : 1,
                message: state.player == 1 ? 'PONG !' : 'PING !',
            };
        case 'VICTORY':
            return { ...state, message: `Player ${state.player} has won !` };
        case 'GAMEOVER':
            return { ...state, message: 'Game over !', isPlaying: false };
        default:
            return state;
    }
}
