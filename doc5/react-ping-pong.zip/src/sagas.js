import { delay, put, takeLeading } from 'redux-saga/effects';

function getRandom(min = 0, max = 10) {
    return min + Math.floor(Math.random() * (max - min + 1));
}

export function* rootSaga() {
    console.log('Saga initialized');
    yield takeLeading('PLAY', playSaga);
}

export function* playSaga(action) {
    let random = getRandom(1, 10);
    yield put({ type: 'GAMESTART' });
    yield delay(2000);
    while (random-- > 0) {
        yield put({ type: 'PING' });
        yield delay(1000);
    }
    yield put({ type: 'VICTORY' });
    yield delay(2000);
    yield put({ type: 'GAMEOVER' });
}
