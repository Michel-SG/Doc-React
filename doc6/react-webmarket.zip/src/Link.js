import { NavLink, useRouteMatch } from 'react-router-dom';

export default function Link({ to, title }) {
    let match = useRouteMatch({
        path: to,
        exact: true,
    });

    return (
        <li className={match ? 'active-link' : ''}>
            <NavLink to={to} className='link'>
                {title}
            </NavLink>
        </li>
    );
}
