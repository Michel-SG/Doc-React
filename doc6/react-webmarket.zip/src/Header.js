import Link from './Link';

import './Header.css';

export default function Header() {
    return (
        <header>
            <img src='/shopping-cart.png' alt='A shopping cart' width='50' />
            <nav>
                <ul>
                    <Link to='/' title='Home' />
                    <Link to='/books' title='Books' />
                    <Link to='/food' title='Food' />
                    <Link to='/clothes' title='Clothes' />
                </ul>
            </nav>
        </header>
    );
}
