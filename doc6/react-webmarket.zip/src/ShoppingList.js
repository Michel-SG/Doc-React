import React, { Component } from 'react';
import { Link } from 'react-router-dom';

export default class ShoppingList extends Component {
    constructor(props) {
        super(props);

        this.state = {
            shoppingListParam: null,
            shoppingList: null,
        };
    }

    componentDidMount() {
        this.setState(state => ({
            shoppingListParam: this.props.match.params.shoppingList,
        }));
        this.loadShoppingList();
    }

    componentDidUpdate() {
        if (
            this.props.match.params.shoppingList !==
            this.state.shoppingListParam
        ) {
            this.setState(state => ({
                shoppingListParam: this.props.match.params.shoppingList,
            }));
            this.loadShoppingList();
        }
    }

    componentWillUnmount() {
        console.log(`UNMOUNTING ${this.state.shoppingListParam}`);
    }

    async loadShoppingList() {
        console.log('Loading...');
        let { shoppingList } = this.props.match.params;
        const response = await fetch(`./${shoppingList}.json`);
        const data = await response.json();
        this.setState(state => ({ shoppingList: data }));
    }

    render() {
        const { shoppingList, shoppingListParam } = this.state;
        if (shoppingList === null) return <p>Chargement...</p>;

        const { title, list } = shoppingList;

        return (
            <div className='ShoppingList'>
                <h2>{title}</h2>
                <ul>
                    {list.map(item => (
                        <li key={item.title}>
                            <h3>
                                <Link to={`/${shoppingListParam}/${item.id}`}>
                                    {item.title}
                                </Link>
                            </h3>
                            <p>{item.description}</p>
                            <hr />
                        </li>
                    ))}
                </ul>
            </div>
        );
    }
}
