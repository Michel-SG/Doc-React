import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router';

export default function ItemDetail() {
    const { shoppingList, id } = useParams();
    const history = useHistory();
    const [item, setItem] = useState(null);

    useEffect(() => {
        const fetchItem = async () => {
            const response = await fetch(`/${shoppingList}.json`);
            const data = await response.json();

            setItem(data.list.find(i => i.id === +id));
        };
        setTimeout(fetchItem, 2000);
    }, [shoppingList, id]);

    if (item === null) return <p>Loading...</p>;

    return (
        <div className='ItemDetail'>
            <h2>{item.title}</h2>
            <p>{item.description}</p>
            <button onClick={() => history.goBack()}>Go back</button>
        </div>
    );
}
