import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

import './App.css';

import Header from './Header';
import Home from './Home';
import ItemDetail from './ItemDetail';
import ShoppingList from './ShoppingList';

function App() {
    return (
        <Router>
            <div className='App'>
                <Header />
                <main>
                    <Switch>
                        <Route exact path='/'>
                            <Home />
                        </Route>
                        <Route
                            path='/:shoppingList'
                            exact
                            component={ShoppingList}
                        />
                        <Route
                            path='/:shoppingList/:id'
                            component={ItemDetail}
                        />
                    </Switch>
                </main>
            </div>
        </Router>
    );
}

export default App;
