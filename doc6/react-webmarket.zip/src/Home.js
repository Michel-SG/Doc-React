import React from 'react';

export default function Home() {
    return (
        <div>
            <h1>Bienvenue sur cette plateforme d'achat en ligne</h1>
            <hr />
            <p>
                Vous trouverez votre bonheur en naviguant via le menu du haut :)
            </p>
        </div>
    );
}
