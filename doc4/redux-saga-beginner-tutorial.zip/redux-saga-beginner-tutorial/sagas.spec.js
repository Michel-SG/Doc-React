import { call, put } from 'redux-saga/effects';
import test from 'tape';

import { delay, incrementAsync } from './sagas';

test('incrementAsync Saga test', assert => {
    const gen = incrementAsync();

    assert.deepEquals(
        gen.next().value,
        call(delay, 1000),
        'incrementAsync Saga must call delay(1000)'
    );

    assert.deepEquals(
        gen.next().value,
        put({ type: 'INCREMENT' }),
        'incrementAsync Saga must dispatch an INCREMENT action'
    );

    assert.deepEquals(
        gen.next(),
        { done: true, value: undefined },
        'incrementAsync Saga must be done'
    );

    assert.end();
});
